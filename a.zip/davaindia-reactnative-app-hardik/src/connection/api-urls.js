export default {
  CONTENT_TYPE: {
    APPLICATION_JSON: 'application/json',
  },

  METHODS: {
    POST: 'POST',
    GET: 'GET',
  },

  PARMS: {
    APIKEY: 'HjgfkbXNK6xrgQO2E6QGRm0ohTP1582J',
  },

  API_URLS: {
    LOCAL: 'http://115.124.111.238:4044/',
    DEVELOPMENT: 'http://115.124.96.40:8090/',
    LIVE: 'http://davaindia.co.in/',
  },
  API_NAME: {
    AUTHENTICATE: 'web/session/authenticate',
  },
};
