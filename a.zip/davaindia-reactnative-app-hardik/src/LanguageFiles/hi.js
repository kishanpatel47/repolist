export default {
  Hindi: 'हिन्दी',
  English: 'अंग्रेज़ी',
  SEARCH: 'खोज',
  SEARCH_BY_COUNTRY: 'देश के आधार पर खोजें',
  Category: 'वर्ग',
};
