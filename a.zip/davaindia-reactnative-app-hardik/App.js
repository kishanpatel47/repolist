/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
} from 'react-native';
import Router from './src/Router';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import strings from './src/LanguageFiles/LocalizedStrings';
import { getLng, setLng } from './src/helper/changeLanguage';
import messaging from '@react-native-firebase/messaging';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as RootNavigation from './src/helper/RootNavigation';
import AsyncStorage from '@react-native-async-storage/async-storage';

const selectLanguage = async () => {
  //https://www.youtube.com/watch?v=JvDcCAw5qnE
  const lngData = await getLng();
  if (lngData) {
    strings.setLanguage(lngData);
  }
};

const App = () => {
  // const navigation = useNavigation();
  const [loading, setLoading] = useState(true);
  const [initialRoute, setInitialRoute] = useState('Notification');
  selectLanguage();

  useEffect(() => {
    // Assume a message-notification contains a "type" property in the data payload of the screen to open
    const unsubscribe = messaging().onMessage(async (remoteMessage) => {
      Alert.alert('A new FCM message arrived!', JSON.stringify(remoteMessage));
    });

    messaging().setBackgroundMessageHandler(async (remoteMessage) => {
      console.log('Message handled in the background!', remoteMessage);
      console.log("data is", remoteMessage.data);
      console.log("data is", remoteMessage.data.ordertrack);
    });

    messaging().onNotificationOpenedApp((remoteMessage) => {
      console.log(
        'Notification caused app to open from background state:',
        remoteMessage,
      );
      console.log('>>>>>');
      console.log("data is", remoteMessage.data);
      // console.log("data is", remoteMessage.data.ordertrack);
      // // Router.navigate('Notification', {});
      // if (remoteMessage.data.ordertrack) {
      //   RootNavigation.navigate('My Orders', { screen: 'OrderTrack', params: { navParams: { orderId: '102' } } }); //code will used for navigate to ORDERTRACK page
      //   // RootNavigation.navigate('OrderTrack', {});
      // } else {
      //   RootNavigation.navigate('Notification', {});
      // }

      RootNavigation.navigate('Notification', {});

      // navigation.push('Notification');
      // navigation.navigate();
      // setInitialRoute(remoteMessage.notification);
    });

    // Check whether an initial notification is available
    messaging()
      .getInitialNotification()
      .then((remoteMessage) => {
        if (remoteMessage) {
          console.log(
            'Notification caused app to open from quit state:',
            remoteMessage.notification,
          );
          // RootNavigation.navigate('Notification', {});
          // setInitialRoute('Notification'); // e.g. "Settings"
          AsyncStorage.setItem('isNotification', 'true');
          // setInitialRoute(remoteMessage.data.type); // e.g. "Settings"
        }
        setLoading(false);
      });
  }, []);

  if (loading) {
    return null;
  }

  return <Router />;
};

const styles = StyleSheet.create({});

export default App;
